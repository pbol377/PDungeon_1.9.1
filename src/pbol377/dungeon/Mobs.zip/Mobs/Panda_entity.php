<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Panda_entity extends Base_Entity {
	const NETWORK_ID = 113;
	}