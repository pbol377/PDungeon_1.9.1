<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Eye_of_ender_signal extends Base_Entity {
	const NETWORK_ID = 70;
	}