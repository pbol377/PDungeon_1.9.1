<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Vindicator extends Base_Entity {
	const NETWORK_ID = 57;
	}