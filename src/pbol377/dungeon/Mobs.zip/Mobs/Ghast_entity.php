<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Ghast_entity extends Base_Entity {
	const NETWORK_ID = 41;
	}