<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Pig extends Base_Entity {
	const NETWORK_ID = 12;
	}