<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Cow extends Base_Entity {
	const NETWORK_ID = 11;
	}