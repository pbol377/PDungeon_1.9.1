<?php

declare(strict_types=1);

namespace pbol377\dungeon\Mobs;

use pocketmine\entity\Monster;

abstract class Base extends Monster {

}