<?php
declare(strict_types = 1);

namespace pbol377\dungeon\Mobs;

class Tnt_entity extends Base_Entity {
	const NETWORK_ID = 65;
	}